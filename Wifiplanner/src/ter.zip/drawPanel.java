import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Line2D;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;



public class drawPanel extends JPanel implements Serializable {
	public int detectedWallnum;
	public int detectedAP;
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public  transient BufferedImage  BGimgIcon;//BG uploaded img
	 private int paneWidth,paneHeight;
	// private MouseHandler mouseHandler = new MouseHandler();
	


	 //-----------------------scale condition var
	 public Line ScaleLine;
	 public float gridDist; 
	 public float gridDistP;
	 public boolean drawingScale = false;
	 public boolean scale = false;
	 //---------------------wall condition var
	 public Line temp ;
	 public  ArrayList<Line> WList=new ArrayList<Line>();
	 public boolean Walldrawing = false;
	 public float curPAF;
	 public float curFreq;
	 public int selectedWall=0;
	 //---------------------------- calculator's vars
	 public JLabel txt7;
	 public float curY=2;
	 public float showCur=0;
	 public int currentMode = 0;//mode of menu
	 //----------------------------------auto Mode vars--------------------
	 private float[] exDists = new float[5];
	 private float[] exVals = new float[5];
	 
	//grid width and height
	 public int gw=20;
	
	 public int npx,npy;//current position of mouse
	 int size;//arraysize
	 public JPanel ChangingPanel;
	 float[] freqf = {2.4f,5.0f};
	 public   JComboBox<String>  changeFreq;
	 JSlider selectPt ;
	//AP var----------------------------------------------
	 public  ArrayList<AP> APs=new ArrayList<AP>();
	 public ArrayList<Spot> Spots	 = new ArrayList<Spot>() ;
	//-----------Zoom vars
	 double Zoomscale;
	 double ZoomInc;
	public drawPanel() {
		Zoomscale = 1.0;
		
		ShowApOptions();
	
	     ScaleLine = new Line(new Point(-1,-1),new Point(-1,-1));

		
	
		
	}
	public void setPath(File path) throws IOException{
		BGimgIcon = ImageIO.read(path);
		paneWidth = BGimgIcon.getWidth();
		paneHeight = BGimgIcon.getHeight();
		//setPreferredSize(new Dimension(758,571));
		 System.out.println("setpath");
		
		
	}
	
	public void setPAF(float paf,int index){
		
		curPAF = paf;
		selectedWall = index;
		
	}
	public void setY(float y){
		curY = y;
		reCal();
		repaint();
		
	}
	public void setGW(int _gw){
		
		gw = _gw;
		
		repaint();
		
	}
	public void setExample(float[] exDi,float[] exVa){
		
		exDists = exDi;
		exVals = exVa;
		
	}
	public void calMMSE(){
		
		
		
	}
	public void setFreq(float freq){
		curFreq = freq;
		
	}
	public void setScale(){
		
		scale = !scale;//change mode to scale or not scale when Scale button has been clicked
		 setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
	}
	public void changeModeTo(int desireMode){
		currentMode = desireMode;
		if(desireMode == 0){
		
	       setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
	       }
		else {
			 setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
			
			
		}
			
		
	}
	public void setZoomScale(double zoomsize)
    {
        Zoomscale = zoomsize;
        revalidate();
        repaint();
    }
	 @Override
	 public Dimension getPreferredSize() {
		 		if(BGimgIcon==null)
		 			return new Dimension(758, 571);
		 			//return new Dimension(800, 600);
		 		else{
		 			
		 			int
		            w = (int)(Zoomscale *  BGimgIcon.getWidth()),
		            h = (int)(Zoomscale * BGimgIcon.getHeight());
		 			return new Dimension(w, h);
		 			//return new Dimension(BGimgIcon.getWidth(), BGimgIcon.getHeight());
		 			
		 		}
	    }
	 @Override
	public void paintComponent(Graphics g) {
		 	super.paintComponent(g);
		 	

		 	//---------------------draw on BGg------------------------------
		 	if(BGimgIcon!=null){
		 		//set up
		 		BufferedImage BGg =	  new BufferedImage(BGimgIcon.getWidth(), BGimgIcon.getHeight(),
		                    BufferedImage.TYPE_INT_ARGB);
		 		Graphics2D g2 = BGg.createGraphics();
		 		
		 		if(Spots!=null){
		 			for(int k =0;k<Spots.size();k++){
		 				g2.setColor(Spots.get(k).getColor());
		 				g2.fillRect(Spots.get(k).getPos().x, Spots.get(k).getPos().y, gw, gw);
		 			
		 			}
		 		}
		 	
		 		//drawAP----------------
		 		if(APs!=null){
		 		for(int i=0; i< APs.size();i++){//for every AP
	        		
		 			g2.setColor(Color.BLUE);
		 			g2.fillOval((APs.get(i).posx-4),(APs.get(i).posy-4),gw,gw);
		 			g2.drawOval(APs.get(i).posx-4,APs.get(i).posy-4,gw,gw);
	        		
	        			
	        		}
		 		}
		 	
			 	  Graphics2D g2d = (Graphics2D) g2;
			        g2d.setColor(Color.blue);
			        g2d.setRenderingHint(
			            RenderingHints.KEY_ANTIALIASING,
			            RenderingHints.VALUE_ANTIALIAS_ON);
			        g2d.setStroke(new BasicStroke(3,
			            BasicStroke.CAP_ROUND, BasicStroke.JOIN_BEVEL));
			        if(drawingScale)//draw only when it's scaling mode
			        { g2d.drawLine(ScaleLine.getP1X(), ScaleLine.getP1Y(),ScaleLine.getP2X(), ScaleLine.getP2Y());}
			        if(Walldrawing){
			        	
			        	g2d.drawLine(temp.getP1X(), temp.getP1Y(),temp.getP2X(),temp.getP2Y());
			        }
			    	
			 		//drawWall---------------
				 	   if(WList != null){
				        	
				        	for(int i=0; i< WList.size(); i++){
				        		//System.out.println(WList.get(i).getPAF());
				        		g2.setColor(WList.get(i).getColor());
				        		g2.drawLine(WList.get(i).getP1X(),WList.get(i).getP1Y(),WList.get(i).getP2X(),WList.get(i).getP2Y());
				        		
				        	}
				        	
				        	
				        }
			 		

		 		Dimension dim = getPreferredSize();
		 	  g.drawImage(BGimgIcon,0,0,dim.width,dim.height, null);
		 		g.drawImage(BGg,0,0,dim.width,dim.height, null);
		 	  
		 		// System.out.println(BGimgIcon.getWidth()+","+BGimgIcon.getHeight());
		 	
		        }
		        //-------------------------------------------------------------------------
		    	  
		     //   g.drawImage(BGimgIcon,0,0,null);
		    for (int i=0;i<this.getWidth();i+=gw) {
	            
	        	  for (int j=0;j<this.getHeight();j+=gw) {
	        		 
	        	  g.drawOval(i,j,1,1);
	        	 
	        	  }
	          }
	
	        	
        	
	        g.drawOval(npx-2, npy-2, 4, 4);
	   	
	
		  }
	
	


	public float spl(float d,float _curK,int _pt){
		
		 float PL = (float) (_pt + _curK - 10*curY*Math.log10(d));
		 return PL;
		
	}
	public ArrayList<Float> ipm(int APx ,int APy,int posx,int  posy){
		ArrayList<Float> PAFS = new ArrayList<Float>();
		boolean intersected = false;
		for(int i=0;i<WList.size();i++){
			if(posx != APx || posy != APy){//do not compare itself
				intersected = Line2D.linesIntersect(APx,APy,posx,posy,
					 WList.get(i).getP1X(),WList.get(i).getP1Y(),WList.get(i).getP2X(),WList.get(i).getP2Y());
			}
			if(intersected){
				float tempPAF = WList.get(i).getPAF();
				PAFS.add(tempPAF);
				
			}
		}
		return PAFS;
	}
	public float findMaxTempVal(float[] _tampVals){
		float temp = -999;
		for(int i=0;i<_tampVals.length;i++){
			if(_tampVals[i]>temp)
				temp = _tampVals[i];
				
		}
		return temp;
		
	}
	public void reCal(){
		 //create Image for Spots---------------
		  

		
		Spots.clear();
		 for(int k=0; k< APs.size();k++){//check all APs
			 //int count = 0;
			 
		 for (int i=0;i<BGimgIcon.getWidth();i+=gw) {
	            
        	  for (int j=0;j<BGimgIcon.getHeight();j+=gw) {
        		  if(i!=APs.get(k).posx || j!=APs.get(k).posy){
        		  
        		  float tempDistP =(float) Point.distance(i, j,APs.get(k).posx ,APs.get(k).posy);//distance in pixel
        		  if(tempDistP<=gridDistP){//if it's less than 70m(but it's in pixel unit)
        			  
        			  float dist = (tempDistP*gridDist)/gw;//convert Pixel to Meter
        			//  System.out.println(APs.get(k).freq);
        			  float tempVal = spl(dist,APs.get(k).curK,APs.get(k).pt);//calculate spl
        			  ArrayList<Float> PAFS = new ArrayList<Float>();
        			  PAFS = ipm(APs.get(k).posx,APs.get(k).posy,i,j);
        			  
        			  for(int m=0; m<PAFS.size();m++){
        				  tempVal= tempVal + PAFS.get(m);
        				 
        			  }
        			  if(tempVal >= -100){//if val < -100 then dont add it to Spots
        			//  System.out.println("value   =  "+tempVal);
        			//  System.out.println("distance =  "+dist+"  meter");
        			//  System.out.println("distance =  "+tempDistP+"  pixel");
        			//  System.out.println("PAFS =  "+PAFS);
        			 Spot tempSpot = new Spot(new Point(i,j),tempVal);
        			 int checkDup = findDupSpot(new Point(i,j));//check DUp
        			 if(checkDup != -1){
        				 if(tempVal > Spots.get(checkDup).value){
        					 Spots.get(checkDup).value = tempVal;
        				 }
        			 }else{
        		
        				 Spots.add(tempSpot);//add to arrayList
        			 }
        			 
        			  }
        			  
        		  }
        	  }
        		  else{
        			 // System.out.println("APs point =  "+APs.get(k).posx+","+APs.get(k).posy);
        			//  System.out.println("spot point = "+i+","+j);
        		  }
        	  }
          }
	 
		 }//check all APs
		//set Color------------------------------------------
		 for(int k =0;k<Spots.size();k++){
     		
     		Color c = findColor(Spots.get(k).value);
     		Spots.get(k).setColor(c);
     			
        
     			        		
     	}
		
		
		
	}
	public int findDupSpot(Point _loc){
		int found=-1;
		
		loop:
		for(int i=0;i<Spots.size();i++){
			//System.out.println(Spots.get(i).getPos()+"   xxxxxxxxxxxxx    "  +_loc);
			if(Spots.get(i).getPos().equals(_loc)){
				//System.out.println("999999999999999999999999999999999999999999");
				found = i;
				break loop;
			}
		
		}
		return found;
		
	}
	public Color findColor(float value){
		int min1 = (int) findMinSpots();
		//min1 *= -1;
		if(value < min1 && value>= -60 ){
			min1 *= -1;
			value *= -1;
			int val = (int) (((value-min1)/(60-min1))*204);//dark green to light green

			Color c = new Color(0,51+val,0,150);
			/*if(c.getGreen()<55){
			System.out.println("color = "+c+"  val = "+val);
			System.out.println("min = -"+min1);
			}else if(c.getGreen()<100)
				System.out.println("color = "+c+"  val = "+val);*/
			return c;
			
		}else if(value < -60 &&value >= -65 ){// light green to lighter green
			int val = (int) ((((-value)-60)/(65-60))*128); 
			//System.out.println(val);
			//System.out.println(value);
			Color c = new Color(val,255,0,150);
			return c;
			
		}else if(value < -65 && value >= -72){//lighter green to pure yellow
			int val = (int) ((((-value)-65)/(72-65))*126); 
			//System.out.println(val);
			//System.out.println(value);
			Color c = new Color(128+val,255,0,150);
			return c;
			
		}else if(value < -72 && value >= -76){//pure yellow to light yellow
			int val = (int) ((((-value)-72)/(76-72))*50); 
			//System.out.println(val);
			//System.out.println(value);
			Color c = new Color(255,255,0+val,150);
			return c;
			
			
		}else if(value < -76 && value >= -85){//lighter yellow to strong orange
			
			int val = (int) ((((-value)-76)/(85-76))*128); 
			//System.out.println(val);
			//System.out.println(value);
			int val2 = (val*51)/128;
			Color c = new Color(255,255-val,51-val2,150);
			return c;
		}else{
			int val = (int) ((((-value)-85)/(100-85))*127); 
			//System.out.println(val);
			//System.out.println(value);
			Color c = new Color(255,128-val,0,150);
			return c;
			
		}
		
		
		
	}
	public float findMinSpots(){
		float temp = -200;
		for(int i=0;i<Spots.size();i++){
			if(Spots.get(i).value>temp){
				temp = Spots.get(i).value;
			}
		}
		return temp;
	}
	public boolean isthereWall(int apx,int apy){
		boolean checker = false;
		loop:
		for(int i=0;i<WList.size();i++){
			double check = Line2D.ptSegDist(WList.get(i).getP1X(),WList.get(i).getP1Y(),
					WList.get(i).getP2X(),WList.get(i).getP2Y(),apx, apy);
			if(check == 0.0){
				checker = true;
				detectedWallnum =i;
				break loop;
			}
			
		}
		return checker;
	}
	public boolean isthereAP(int apx,int apy){
		boolean checker = false;
		loop:
			 for(int i=0;i<APs.size();i++){
				 if(APs.get(i).getPos().equals(new Point(apx,apy)))
				 {
					 checker = true;
					 detectedAP = i;
					 break loop;
				 } 
			 }
		return checker;
		
		
		
	}
	public void ShowApOptions(){
		ChangingPanel = new JPanel();
      String[] freqs = {"2.4 GHz","5.0GHz"};
      changeFreq  = new JComboBox<String>(freqs);
      changeFreq.setSelectedIndex(0);
      changeFreq.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			float selectedFreq = freqf[changeFreq.getSelectedIndex()]; 
			APs.get(detectedAP).setFreq(selectedFreq);
			System.out.println(selectedFreq);
			reCal();
			repaint();
		}
	});
      ChangingPanel.add(changeFreq);
      
      selectPt = new JSlider(JSlider.HORIZONTAL, 0, 10, 1);
      selectPt.setMinorTickSpacing(1);
      selectPt.setMajorTickSpacing(2);
       selectPt.setPaintTicks(true);
      selectPt.setPaintLabels(true);
      selectPt.addChangeListener(new ChangeListener() {
			 
	         @Override
			public void stateChanged(ChangeEvent e) {
	            int value = selectPt.getValue();
	            APs.get(detectedAP).pt = value;
	            reCal();
				repaint();
	         }
	});
      ChangingPanel.add(selectPt);
  

		JButton okbtn = new JButton("OK");
  		okbtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				 
				ChangingPanel.setVisible(false);
			}
		});
  		
  		ChangingPanel.add(okbtn);
  		ChangingPanel.setVisible(false);
  		add(ChangingPanel);
	
}
	
	public void reset(){
		gw = 20;		
	    WList = new ArrayList<Line>();
		APs = new ArrayList<AP>();
		Spots = new ArrayList<Spot>();
		gridDist = 0;
		gridDistP = 0;	
		curY = 2;
		
		
	}
	
}
